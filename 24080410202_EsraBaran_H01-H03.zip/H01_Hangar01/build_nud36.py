"""Hangar 01 - Nu.D.36'dan esinlenen low-poly cift kanatli ucak.
Foydeki olculer ve adimlarla Blender'da (bpy) kurulur.
Cikti: Nu_D36.blend, Nu_D36.fbx, Nu_D36.glb (ev klasorunde Nu_D36_Hafta1)

KULLANIM (Blender 5.2 LTS):
  1. Blender'i ac, ustteki sekmelerden "Scripting"e gec.
  2. Text Editor'de "Open" ile bu dosyayi ac (ya da yapistir).
  3. "Run Script" (Alt + P). Sahnedeki mesh nesneleri silinir, ucak kurulur
     ve dosyalar asagidaki OUT klasorune kaydedilir.
"""
import os, math
import bpy, bmesh
from mathutils import Vector

OUT = os.path.join(os.path.expanduser("~"), "Desktop", "Nu_D36_Hafta1")
os.makedirs(OUT, exist_ok=True)

# ---------- 02: Sahne ve birimler ----------
if bpy.context.object and bpy.context.object.mode != 'OBJECT':
    bpy.ops.object.mode_set(mode='OBJECT')
sc = bpy.context.scene
sc.unit_settings.system = 'METRIC'
sc.unit_settings.scale_length = 1.0
sc.unit_settings.length_unit = 'METERS'
for ob in list(bpy.data.objects):
    if ob.type == 'MESH':          # baslangic kupunu sil, kamera ve isik kalsin
        bpy.data.objects.remove(ob, do_unlink=True)
for me in list(bpy.data.meshes):   # betik yeniden calisirsa eskiler temizlensin
    if me.users == 0:
        bpy.data.meshes.remove(me)
for m in list(bpy.data.materials):
    if m.users == 0:
        bpy.data.materials.remove(m)

# ---------- 07: Malzemeler ----------
def mat(name, rgb, rough=0.6):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    m.diffuse_color = (*rgb, 1)
    return m

M_GOVDE  = mat("Govde_Kirmizi", (0.62, 0.05, 0.04))
M_KANAT  = mat("Kanat_Krem",    (0.85, 0.78, 0.60))
M_MOTOR  = mat("Motor_Gri",     (0.35, 0.36, 0.38), 0.4)
M_LASTIK = mat("Lastik_Siyah",  (0.03, 0.03, 0.03), 0.8)
M_KOKPIT = mat("Kokpit_Koyu",   (0.08, 0.06, 0.05), 0.9)
M_DIKME  = mat("Dikme_Koyu",    (0.18, 0.18, 0.18), 0.5)

def new_obj(name, bm, material):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me); bm.free()
    ob = bpy.data.objects.new(name, me)
    sc.collection.objects.link(ob)
    ob.data.materials.append(material)
    return ob

def box(name, size, loc, material):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co = Vector((v.co.x * size[0], v.co.y * size[1], v.co.z * size[2])) + Vector(loc)
    return new_obj(name, bm, material)

def cyl(name, verts, r, depth, loc, axis, material):
    """axis: 'X', 'Y' ya da 'Z' - silindirin uzandigi eksen"""
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=verts, radius1=r, radius2=r, depth=depth)
    for v in bm.verts:
        x, y, z = v.co
        if axis == 'X':   v.co = Vector((z, y, x))      # R -> Y -> 90
        elif axis == 'Y': v.co = Vector((x, z, y))      # R -> X -> 90
        v.co += Vector(loc)
    return new_obj(name, bm, material)

def strut(name, a, b, r=0.04, material=None):
    """Iki nokta arasinda 8 kenarli dikme"""
    a, b = Vector(a), Vector(b)
    d = b - a
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=8, radius1=r, radius2=r, depth=d.length)
    rot = Vector((0, 0, 1)).rotation_difference(d.normalized()).to_matrix()
    mid = (a + b) / 2
    for v in bm.verts:
        v.co = rot @ v.co + mid
    return new_obj(name, bm, material or M_DIKME)

# ---------- 03: Govde ----------
# Kesitler (y, yari genislik, alt z, ust z). Burun -Y, kuyruk +Y.
# Bastaki kutu 0,9 x 6,4 x 1,1 m; halka kesimlerle kuyruk inceltildi.
S = [(-2.9, 0.45, 0.55, 1.60),
     (-1.0, 0.45, 0.50, 1.60),
     (-0.4, 0.45, 0.50, 1.60),
     ( 0.0, 0.45, 0.50, 1.60),
     ( 0.6, 0.45, 0.50, 1.60),
     ( 1.4, 0.42, 0.55, 1.58),
     ( 2.5, 0.28, 0.70, 1.42),
     ( 3.5, 0.12, 0.85, 1.18)]
bm = bmesh.new()
rings = []
for y, w, zb, zt in S:
    rings.append([bm.verts.new((-w, y, zb)), bm.verts.new((w, y, zb)),
                  bm.verts.new((w, y, zt)), bm.verts.new((-w, y, zt))])
top_faces = []
for i in range(len(rings) - 1):
    a, b = rings[i], rings[i + 1]
    bm.faces.new((a[0], a[1], b[1], b[0]))                 # alt
    bm.faces.new((a[1], a[2], b[2], b[1]))                 # sag
    top_faces.append(bm.faces.new((a[2], a[3], b[3], b[2])))  # ust
    bm.faces.new((a[3], a[0], b[0], b[3]))                 # sol
bm.faces.new(rings[0][::-1])
bm.faces.new(rings[-1])
bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
# Kokpitler: iki ust yuze I (inset) + E ile iceri cek
kokpit = [top_faces[1], top_faces[3]]
res = bmesh.ops.inset_individual(bm, faces=kokpit, thickness=0.12, depth=0.0)
for f in kokpit:
    f.material_index = 1
    bmesh.ops.translate(bm, verts=f.verts, vec=(0, 0, -0.35))
govde = new_obj("Govde", bm, M_GOVDE)
govde.data.materials.append(M_KOKPIT)

# ---------- 04: Kanatlar ----------
UST_Z = 2.44 - 0.075           # ust kanadin ust yuzu yerden 2,44 m
ALT_Z = 0.65
UST_Y, ALT_Y = -0.9, -0.6      # ust kanat 0,3 m one (stagger)
box("UstKanat", (9.74, 1.5, 0.15), (0, UST_Y, UST_Z), M_KANAT)
box("AltKanat", (8.5, 1.5, 0.15), (0, ALT_Y, ALT_Z), M_KANAT)
for sx in (-1, 1):
    for dy in (-0.45, 0.45):   # kanatlar arasi ikiser dikme
        strut("KanatDikme", (sx * 3.4, ALT_Y + dy, ALT_Z + 0.075), (sx * 3.4, UST_Y + dy, UST_Z - 0.075))
    for dy in (-0.4, 0.3):     # kabin dikmeleri
        strut("KabinDikme", (sx * 0.38, UST_Y + dy, 1.58), (sx * 0.30, UST_Y + dy, UST_Z - 0.075))

# ---------- 05: Kuyruk ve inis takimi ----------
box("YatayStabilizor", (3.0, 0.9, 0.08), (0, 3.25, 1.05), M_KANAT)
dik = box("DikeyStabilizor", (0.08, 1.0, 1.0), (0, 3.2, 1.18 + 0.5), M_GOVDE)
for v in dik.data.vertices:    # ust on kenari geri cek: egimli dumen
    if v.co.z > 2.0 and v.co.y < 3.0:
        v.co.y += 0.55
for sx in (-1, 1):
    cyl("Teker", 12, 0.35, 0.15, (sx * 0.95, -1.15, 0.35), 'X', M_LASTIK)
    strut("TekerDikme", (sx * 0.88, -1.15, 0.35), (sx * 0.30, -1.65, 0.52))
    strut("TekerDikme", (sx * 0.88, -1.15, 0.35), (sx * 0.30, -0.65, 0.50))
strut("TekerAks", (-0.88, -1.15, 0.35), (0.88, -1.15, 0.35), 0.035)
strut("KuyrukKizagi", (0, 3.25, 0.82), (0, 3.55, 0.02), 0.035)

# ---------- 06: Motor ve pervane ----------
MOTOR_Z = 1.075
cyl("Motor", 18, 0.55, 0.45, (0, -3.125, MOTOR_Z), 'Y', M_MOTOR)
for i in range(9):             # bonus: 9 silindirli yildiz motor
    a = 2 * math.pi * i / 9
    dx, dz = math.sin(a), math.cos(a)
    strut("Silindir", (dx * 0.40, -3.2, MOTOR_Z + dz * 0.40),
          (dx * 0.68, -3.2, MOTOR_Z + dz * 0.68), 0.075, M_MOTOR)

# Foyde 2,2 m; govde yatay durdugu icin ucu zemine girmesin diye 2,0 m
pervane = box("Pervane", (2.0, 0.08, 0.18), (0, -3.39, MOTOR_Z), M_MOTOR)
cyl("Kep", 12, 0.12, 0.25, (0, -3.42, MOTOR_Z), 'Y', M_MOTOR)  # pervane gobegi
kep = bpy.data.objects["Kep"]

# Pervane + gobek tek nesne: "Pervane"
for o in bpy.context.selected_objects: o.select_set(False)
pervane.select_set(True); kep.select_set(True)
bpy.context.view_layer.objects.active = pervane
bpy.ops.object.join()
bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

# ---------- 07: Birlestir -> Nu_D36 ----------
bpy.ops.object.select_all(action='DESELECT')
for o in sc.objects:
    if o.type == 'MESH' and o.name != "Pervane":
        o.select_set(True)
bpy.context.view_layer.objects.active = govde
bpy.ops.object.join()
govde.name = govde.data.name = "Nu_D36"
bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
pervane.data.name = "Pervane"

# Yuz yonlerini duzelt (Shift + N)
for o in (govde, pervane):
    bm = bmesh.new(); bm.from_mesh(o.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(o.data); bm.free()

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "Nu_D36.blend"))

# ---------- 08: FBX ve GLB disa aktar ----------
bpy.ops.object.select_all(action='DESELECT')
govde.select_set(True); pervane.select_set(True)
bpy.ops.export_scene.fbx(
    filepath=os.path.join(OUT, "Nu_D36.fbx"),
    use_selection=True,
    apply_scale_options='FBX_SCALE_ALL',
    axis_forward='-Z', axis_up='Y',
    bake_space_transform=True,       # Apply Transform
    object_types={'MESH'},
    mesh_smooth_type='FACE')
bpy.ops.export_scene.gltf(
    filepath=os.path.join(OUT, "Nu_D36.glb"),
    export_format='GLB', use_selection=True)

# Rapor
from mathutils import Vector as V
def bbox(o):
    cs = [o.matrix_world @ V(c) for c in o.bound_box]
    return [round(min(c[i] for c in cs), 3) for i in range(3)], [round(max(c[i] for c in cs), 3) for i in range(3)]
for o in (govde, pervane):
    print(o.name, "origin", tuple(round(x, 3) for x in o.location), "bbox", bbox(o),
          "tris", sum(len(p.vertices) - 2 for p in o.data.polygons))
print("Blender", bpy.app.version_string)
