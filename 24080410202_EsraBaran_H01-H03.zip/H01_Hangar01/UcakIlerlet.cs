using UnityEngine;

// Bonus görev: Uçağı burnunun baktığı yönde (yerel +Z) sabit hızla ilerletir.
// En üstteki Nu_D36 nesnesine eklenir.
public class UcakIlerlet : MonoBehaviour
{
    // metre / saniye
    [SerializeField] private float hiz = 8f;

    private void Update()
    {
        transform.Translate(Vector3.forward * hiz * Time.deltaTime);
    }
}
